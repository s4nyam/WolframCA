# Wolfram-Elementary-Cellular-Automata
The Wolfram Elementary Cellular Automata visualised in p5. You can change the colors and the the rules for evolution

### Demo
[P5 Demo](https://editor.p5js.org/Arnav-Sirigere/full/LXAysJpBj)
